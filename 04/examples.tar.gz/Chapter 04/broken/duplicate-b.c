/* duplicate-b.c — второе определение той же функции. */
#include <stdio.h>

int helper(void)
{
    return 2;
}

void print_b(void)
{
    printf("B: helper=%d\n", helper());
}
