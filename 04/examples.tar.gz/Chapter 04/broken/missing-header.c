/* missing-header.c — забыт #include <string.h>.
 *
 * Сборка: gcc missing-header.c -o missing
 * GCC 13: warning: implicit declaration of function 'strlen'
 * С -Werror: error — сборка останавливается.
 *
 * Причина: без объявления компилятор предполагает int, а strlen
 * возвращает size_t — на 64-битной платформе это разные типы.
 */
#include <stdio.h>

int main(void)
{
    const char *text = "Linux";
    printf("len=%zu\n", strlen(text));
    return 0;
}
