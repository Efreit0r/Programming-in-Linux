/* memory.c — выход за границу массива.
 *
 * Обычная сборка: gcc memory.c -o memory && ./memory
 *   Ошибка может «пройти незамеченной» — это и есть худший случай.
 *
 * С санитайзером:
 *   gcc -fsanitize=address -g memory.c -o memory && ./memory
 *   AddressSanitizer: heap-buffer-overflow
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *data = malloc(4 * sizeof *data);
    if (!data)
        return 1;

    for (int i = 0; i <= 4; i++)   /* ошибка: i == 4 за границей */
        data[i] = i * i;

    printf("last=%d\n", data[3]);
    free(data);
    return 0;
}
