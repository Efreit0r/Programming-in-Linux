/* duplicate-a.c — часть ошибки «multiple definition».
 *
 * Сборка: gcc duplicate-a.c duplicate-b.c -o dup
 * Ожидаемо: multiple definition of `helper'
 *
 * Причина: функция определена в двух .c без static и без extern.
 * Лечение: оставить одно определение, а в заголовке — только прототип.
 */
#include <stdio.h>

int helper(void)
{
    return 1;
}

void print_a(void)
{
    printf("A: helper=%d\n", helper());
}
