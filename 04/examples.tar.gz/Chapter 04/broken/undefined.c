/* undefined.c — ошибка линковки: функция объявлена, но нигде не определена.
 *
 * Сборка: gcc undefined.c -o undefined
 * Ожидаемо: undefined reference to `greet'
 *
 * Причина: greet() объявлена в greet.h, но объектный файл greet.o
 * в линковку не попал — исходник просто не передали компилятору.
 * Лечение: gcc undefined.c ../hello/greet.c -o undefined
 */
#include "../hello/greet.h"

#include <stdio.h>

int main(void)
{
    printf("%s\n", greet("world"));
    return 0;
}
