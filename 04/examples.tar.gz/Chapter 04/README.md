# Chapter 04 — примеры к практикуму «Сборка программ в Linux»

Все примеры проверены на GCC 13.3, GNU Make 4.3, CMake 3.28 (Ubuntu 24.04).
На занятии архив с этими файлами распаковывается в `~/build-lab`:

```bash
mkdir -p ~/build-lab && cd ~/build-lab
curl -LO https://efreit0r.github.io/Programming-in-Linux/04/examples.tar.gz
tar xzf examples.tar.gz        # появится каталог «Chapter 04»
cd "Chapter 04/hello"          # отсюда начинается практика
```

Дальше все команды в этом файле выполняются из `~/build-lab/Chapter 04/...`.
Если интернета нет, тот же `examples.tar.gz` раздаётся на занятии — команда
`tar xzf` не меняется.

## Что внутри

```
hello/    рабочий проект: два .c, один .h, Makefile и CMakeLists.txt
broken/   по одному примеру на каждую типичную ошибку сборки
stages/   один файл, чтобы разобрать четыре этапа вручную
```

## hello/ — «правильный» проект

```
gcc --version          # нужен любой gcc/clang
make                   # сборка через GNU Make
./hello                # Hello, Linux!
./hello "СПбГУ"        # аргумент командной строки

cmake -S . -B build    # сборка через CMake, артефакты в build/
cmake --build build
./build/hello CMake
```

Файлы: `greet.h` (интерфейс), `greet.c` (реализация), `main.c` (точка входа).
Makefile специально показывает переменные, шаблонное правило `%.o: %.c`,
автоматические переменные `$@ $< $^` и заголовок в зависимостях.

## broken/ — ошибки и их причины

| Файл | Команда | Ожидаемый результат |
| --- | --- | --- |
| `undefined.c` | `gcc undefined.c -o u` | `undefined reference to 'greet'` |
| `duplicate-a.c` + `duplicate-b.c` | `gcc duplicate-a.c duplicate-b.c -o d` | `multiple definition of 'helper'` |
| `missing-header.c` | `gcc missing-header.c -o m` | предупреждение `implicit declaration of function 'strlen'` |
| то же с `-Werror` | `gcc -Werror missing-header.c -o m` | ошибка, сборка останавливается |
| `Makefile-spaces` | `make -f Makefile-spaces` | `*** missing separator.  Stop.` |
| `memory.c` | `gcc memory.c -o mem && ./mem` | «работает»: `last=9`, ошибка незаметна |
| `memory.c` с ASan | `gcc -fsanitize=address -g memory.c -o mem && ./mem` | `heap-buffer-overflow ... WRITE of size 4` |

Каждый файл содержит комментарий в начале: что происходит и как исправить.

## stages/ — четыре этапа

```bash
gcc -E demo.c > demo.i     # препроцессор: раскрыты #include и #define
gcc -S demo.c              # компилятор: demo.s
gcc -c demo.c              # ассемблер: demo.o
gcc demo.o -o demo         # линковщик: demo
```

В `demo.i` видно, что `VERSION` превратился в `"1.0"`, а `SQUARE(7)` —
в `((7) * (7))`. В `nm demo.o` есть `T main` и `U printf`.

## Чего в каталоге быть не должно

`*.o`, `hello`, `demo`, `demo.i`, `demo.s`, `build/` — результаты сборки.
После практики достаточно `make clean` и `rm -rf build`.
