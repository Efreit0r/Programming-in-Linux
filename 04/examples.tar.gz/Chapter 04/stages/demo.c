/* demo.c — маленький файл, на котором видно все четыре этапа.
 *
 *   gcc -E demo.c            # только препроцессор
 *   gcc -S demo.c            # ассемблер (demo.s)
 *   gcc -c demo.c            # объектный файл (demo.o)
 *   gcc demo.c -o demo       # линковка (исполняемый файл)
 */
#include <stdio.h>

#define VERSION "1.0"
#define SQUARE(x) ((x) * (x))

int global_counter = 0;
static const char *app_name = "stages";

int main(void)
{
    global_counter++;
    printf("%s %s: %d\n", app_name, VERSION, SQUARE(7));
    return 0;
}
