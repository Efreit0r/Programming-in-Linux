/* main.c — точка входа учебного проекта.
 *
 * Проект специально разбит на два файла .c, чтобы было видно,
 * зачем нужны отдельная компиляция и линковка.
 */
#include "greet.h"

#include <stdio.h>

int main(int argc, char **argv)
{
    const char *name = (argc > 1) ? argv[1] : "Linux";

    printf("%s\n", greet(name));
    printf("greet() вызван %d раз\n", greet_calls());

    return 0;
}
