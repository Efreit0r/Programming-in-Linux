/* main.c — маленькая программа, которую собирает autotools.
 *
 * Никаких зависимостей: задача примера — показать configure.ac и Makefile.am,
 * а не логику. Рядом лежит тот же hello, собранный make, CMake и Meson.
 */
#include <stdio.h>

int main(void)
{
    printf("Hello from autotools!\n");
    return 0;
}
